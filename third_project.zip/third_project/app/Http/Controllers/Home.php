<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Home extends Controller
{

    public function index()
    {
        return view('home.home');
    }

    public function fullName()
    {
        return view('fullName.fullName');
    }
    public function calcu()
    {
        return view('calculator.calculator');
    }
}
