@extends('master')

@section('title')
    Calculator
@endsection

@section('body')
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card card-body">
                    <form action="{{route('getfullname')}}" method="post">
                        @csrf
                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">First Number</label>
                            <div class="col-md-8">
                                <input type="text" name="first_number" class="form-control">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">Last Number</label>
                            <div class="col-md-8">
                                <input type="text" name="last_number" class="form-control">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">Option</label>
                            <div class="col-md-8">
                                <label for=""><input type="radio" name="option" value="+">ADD</label>
                                <label for=""><input type="radio" name="option" value="-">SUB</label>
                                <label for=""><input type="radio" name="option" value="*">MULT</label>
                                <label for=""><input type="radio" name="option" value="/">DIV</label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">Result</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" value="">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label"></label>
                            <div class="col-md-8">
                                <input type="submit"  class="btn btn-outline-success" value="submit">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
