@extends('master')
@section('title')
    Home
@endsection

@section('body')
    <h2 class="text-center text-success">Hello World</h2>
@endsection
