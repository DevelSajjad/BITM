<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Home;
use App\Http\Controllers\FullNameController;

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/', [Home::class, 'index']);
Route::get('/full-name', [Home::class, 'fullName']);
Route::get('/calculator', [Home::class, 'calcu'])->name('cal');
Route::post('/get-full-name', [FullNameController::class, 'getFullName'])->name('getfullname');
